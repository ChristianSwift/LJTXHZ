/**
 * @package Symetrio
 * @author Wonster
 * @link http://wonster.co/
 */

tinyMCE.addI18n({en:{
		systempanel:{
			desc : 'Theme shortcodes'
		}
	}
});